<?php

namespace App\Models\Challan;

use Illuminate\Database\Eloquent\Model;

class Challan extends Model
{
    protected $guarded = [];
}
