$(function(){		
    
    "use strict";
    	
    new CBPGridGallery( document.getElementById( 'grid-gallery' ) );
});