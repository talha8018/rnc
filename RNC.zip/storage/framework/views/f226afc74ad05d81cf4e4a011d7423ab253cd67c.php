<?php $__env->startSection('title'); ?> File Upload <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

            
    <div class="page-title">
        <h3 class="breadcrumb-header">Upload File</h3>
    </div>
    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <h4 class="panel-title">Last uploaded file on 23 Dec, 2017 by Talha.</h4>
                    </div>
                    <div class="panel-body">
                        <form class="form-inline" action="<?php echo e(url('challan/upload')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label class="btn-bs-file btn btn-default"> Browse File
                                    <input type="file" class="" name="challan">
                                </label>
                            </div>
                            

                            <button type="submit" class="btn btn-primary">Upload</button>
                        </form>
                    </div>
                </div>
            </div>
        </div><!-- Row -->
    </div><!-- Main Wrapper -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>