<div class="page-sidebar">
                <a class="logo-box" href="<?php echo e(url('/')); ?>">
                    <span>RNC</span>
                    <i class="icon-radio_button_unchecked" id="fixed-sidebar-toggle-button"></i>
                    <i class="icon-close" id="sidebar-toggle-button-close"></i>
                </a>
                <div class="page-sidebar-inner">
                    <div class="page-sidebar-menu">
                        <ul class="accordion-menu">
                            <li>
                                <a href="javascript:void(0);">
                                    <i class="menu-icon fa fa-file-excel-o"></i><span>Challan</span><i class="accordion-icon fa fa-angle-left"></i>
                                </a>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo e(url('challan/file-upload')); ?>">File Upload</a></li>
                                    <li><a href="#">Generate Challan</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- /Page Sidebar -->