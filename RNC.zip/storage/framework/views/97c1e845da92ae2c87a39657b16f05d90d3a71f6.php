<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Royal National College">
        <meta name="keywords" content="rnc,college">
        <meta name="author" content="Muhammad Talha">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <!-- Title -->
        <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
        <link href="<?php echo e(url('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('assets/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('assets/plugins/icomoon/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('assets/plugins/uniform/css/default.css')); ?>" rel="stylesheet"/>
        <link href="<?php echo e(url('assets/plugins/switchery/switchery.min.css')); ?>" rel="stylesheet"/>
        <?php echo $__env->yieldContent('css'); ?>
        <!-- Theme Styles -->
        <link href="<?php echo e(url('assets/css/space.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('assets/css/custom.css')); ?>" rel="stylesheet">
    </head>
    <body>
    
    <!-- Page Container -->
    <div class="page-container">
        <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Content -->
        <div class="page-content">            
            <?php echo $__env->make('includes.page-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>            
            <!-- Page Inner -->
            <div class="page-inner">
                        <?php echo $__env->yieldContent('content'); ?>
                <div class="page-footer">
                    <p>Made with <i class="fa fa-heart"></i> by talha8018</p>
                </div>
            </div><!-- /Page Inner -->

        </div><!-- /Page Content -->
    </div><!-- /Page Container -->
        
        
        <!-- Javascripts -->
        <script src="<?php echo e(url('assets/plugins/jquery/jquery-3.1.0.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/uniform/js/jquery.uniform.standalone.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/switchery/switchery.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/space.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>