<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

            
    <div class="page-title">
        <h3 class="breadcrumb-header">Blank Page</h3>
    </div>
    <div id="main-wrapper">
        <div class="row">
            
        </div><!-- Row -->
    </div><!-- Main Wrapper -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>