@extends('layouts.master')
@section('title') Dashboard @endsection
@section('content')

            
    <div class="page-title">
        <h3 class="breadcrumb-header">Blank Page</h3>
    </div>
    <div id="main-wrapper">
        <div class="row">
            
        </div><!-- Row -->
    </div><!-- Main Wrapper -->


@endsection
